<footer>
  <p>&copy 2024 SMK AL-HUSNA</p>
</footer>

<script type="text/javascript" src="assets/js/transaksi.js"></script>
</body>

</html>