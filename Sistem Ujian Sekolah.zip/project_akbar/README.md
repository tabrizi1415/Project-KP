# Siposweb
Sistem Informasi Point of Sales berbasis Web

|![smartmockups_kgyl8muy](https://user-images.githubusercontent.com/14845590/175760659-109538e1-e731-4561-a3d7-3368edda7e3d.png)|![smartmockups_kgyl8vfr](https://user-images.githubusercontent.com/14845590/175760660-8d4c78f4-44a0-40d8-b413-cb983dc639be.png)|
|-|-|
|![smartmockups_kgyl92o9](https://user-images.githubusercontent.com/14845590/175760665-fe5e8ee0-ef4c-4706-9f84-242d40789c30.png)|![smartmockups_kgyl9f6l](https://user-images.githubusercontent.com/14845590/175760661-09c4bcab-04f5-4e24-89c9-cdcc3ec21edc.png)|
|![smartmockups_kgyl9n1q](https://user-images.githubusercontent.com/14845590/175760663-2df81dca-594b-4900-847d-4d3523b166d7.png)|![smartmockups_kgyl9uwa](https://user-images.githubusercontent.com/14845590/175760664-d7a8e441-0c49-4b60-bbb7-31b24c02049e.png)|
|![smartmockups_kgyla2up](https://user-images.githubusercontent.com/14845590/175760666-8e003e30-0b38-4ac9-8003-56961d8e8d52.png)|![smartmockups_kgyol9kj](https://user-images.githubusercontent.com/14845590/175760669-14722a0b-0e4f-41a7-89f3-84466e3aa8d4.png)|
