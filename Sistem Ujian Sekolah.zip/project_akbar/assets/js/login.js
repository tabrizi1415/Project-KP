function closeModal() {
	document.getElementById("modal-login-failed").style.display = "none";
}